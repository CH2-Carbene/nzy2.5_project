JSon-Editor by ZTn
==================
[![appveyor-build-status](https://ci.appveyor.com/api/projects/status/ojmuwo49qwb1xlae/branch/master?svg=true)](https://ci.appveyor.com/project/zetoken/json-editor/branch/master)

A simple JSON Editor written in C# using the excellent Json.NET API from http://newtonsoft.com/json.

Work is still in progress: in case of any bug, please open an issue, I'd be happy to fix it.

[Download last build from appveyor](https://ci.appveyor.com/api/projects/zetoken/json-editor/artifacts/Json%20Editor/bin/ztn-json-editor.zip).

![screenshot](https://github.com/zetoken/JSon-Editor/wiki/screenshot512.png)
