﻿
namespace ZTn.Json.JsonTreeView
{
    class JPropertyContextMenuStrip : JTokenContextMenuStrip
    {
    }
}
