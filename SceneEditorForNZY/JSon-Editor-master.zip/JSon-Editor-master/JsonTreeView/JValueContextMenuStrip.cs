﻿
namespace ZTn.Json.JsonTreeView
{
    class JValueContextMenuStrip : JTokenContextMenuStrip
    {
    }
}
